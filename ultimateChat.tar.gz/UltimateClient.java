import java.io.IOException;
import java.net.Socket;

public class UltimateClient {
    public static void main(String[] a){
        Socket client;
        try {
            client = new Socket("localhost", 8888);
                new Thread(new Send(client)).start();
                new Thread(new Receive(client)).start();

        }catch (IOException ioe){
            ioe.printStackTrace();
        }

    }
}
