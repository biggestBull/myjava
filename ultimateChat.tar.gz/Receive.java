import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.List;
import java.util.regex.Pattern;

public class Receive implements Runnable{
    private BufferedInputStream bis=null;
    private Socket client;
    private DataInputStream dis=null;
    private Pattern checkRegex;
    private List<String> containerGro;
    private List<String> containerPri;
    private boolean type;
    private String[] name;
    Receive(Socket client){
        this.client=client;
        this.type=false;
        this.checkRegex=Pattern.compile("^>>>[A-Z]\\s.*");
        try {
            bis=new BufferedInputStream(this.client.getInputStream());
            dis=new DataInputStream(bis);
        }catch (IOException ioe){
            ioe.printStackTrace();
        }
    }
    Receive(Socket client,  List<String> containerPri,List<String> containerGro,String[] name){
        this(client);
        this.name=name;
        this.type=true;
        this.containerGro=containerGro;
        this.containerPri=containerPri;
    }
    @Override
    public void run(){
        if(!type)
            clientReceive();
        else
            serverReceive();

    }
    private void clientReceive(){
        while(true) {
            try {
                String mesg=this.dis.readUTF();
                System.out.println(mesg);
            } catch (IOException ioe) {
                ioe.printStackTrace();
                TogetherClose.close(dis, bis, client);
                System.out.println("接收，客户端，ioe，报错");
                break;
            }
        }
    }
    private void serverReceive(){
        while(true){
            try{
                String mesg=this.dis.readUTF();
                if(checkRegex.matcher(mesg).find()){
                    this.containerPri.add(mesg);
                    System.out.println("私聊+1: "+mesg);
                }else if (mesg.equals("exit;")){
                    String threadName=Thread.currentThread().getName();
                    System.out.println("线程退出："+threadName);
                    int stringName=Integer.parseInt(threadName.split("-")[1]);
                    containerGro.add("系统通知： <<<"+name[stringName]+">>> 退出！");
                    TogetherClose.close(dis, bis, client);
                    System.out.println("接收，服务器，exit，退出");
                    break;
                }else {
                    this.containerGro.add(mesg);
                    System.out.println("群聊+1: "+mesg);
                }
                System.out.println("group容器： "+this.containerGro);
                System.out.println("private容器： "+this.containerPri);

            }catch (IOException ioe){
                ioe.printStackTrace();
                String threadName=Thread.currentThread().getName();
                System.out.println("线程退出："+threadName);
                int stringName=Integer.parseInt(threadName.split("-")[1]);
                containerGro.add("系统通知： <<<"+name[stringName]+">>> 退出！");
                TogetherClose.close(dis, bis, client);
                System.out.println("接收，服务器，ioe，报错");
                break;
            }
        }
    }


}
