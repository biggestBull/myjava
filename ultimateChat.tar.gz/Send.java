import java.io.*;
import java.net.Socket;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class Send implements Runnable{
    private Socket client;
    private List<Socket> clients;
    private BufferedReader br;
    private BufferedOutputStream bos;
//    DataInputStream dis=null;
    private DataOutputStream dos;
    private List<String> containerPri=null;
    private List<String> containerGro=null;
    private Pattern toRegex;
    private boolean type;                     //0 server group,1 server private,2 client group,3 client private
    Send(Socket client) throws IOException{
        this.client=client;
        type=false;
        br = new BufferedReader(new InputStreamReader(System.in));
        bos=new BufferedOutputStream(this.client.getOutputStream());
        dos=new DataOutputStream(bos);
        toRegex=Pattern.compile(">{3}([A-Z])\\s.*");
    }
     Send(Socket client, List<String> containerPri, List<String> containerGro, List<Socket> clients) throws IOException{
        this(client);
        this.clients=clients;
        this.type=true ;
        this.containerPri=containerPri;
        this.containerGro=containerGro;
    }
    @Override
    public void run(){
        if(!this.type)
            clientSend();
        else
            serverSend();
    }
    private void clientSend(){
        while(true){
            try {
                String input=br.readLine();
                this.dos.writeUTF(input);
                this.dos.flush();
                if(input.equals("exit;")){
                    TogetherClose.close(dos,bos,br,client);
                    System.out.println("客户端，发送,exit，报错");
                    break;
                }
            }catch (IOException ioe){
                ioe.printStackTrace();
                TogetherClose.close(dos,bos,br,client);
                System.out.println("客户端，发送，报错");
                break;
            }
        }

    }
    private void serverSend(){
//        System.out.println("当前线程： "+Thread.currentThread().getName());
        while(true){
//            String threadName=Thread.currentThread().getName();   //关键的一句是这个。Why?
//            System.out.println(Thread.currentThread().isAlive());
//            System.out.println(Thread.currentThread().getState());
            if(containerPri.isEmpty()&&containerGro.isEmpty()){
                try {
                    Thread.sleep(200);
                }catch (InterruptedException ie){
                    ie.printStackTrace();
                }

                continue;
            }

            for(int i=0;i<containerPri.size();i++) {
                Matcher m=toRegex.matcher(containerPri.get(i));
                if(m.find()) {
                    if (m.group(1).equals(Thread.currentThread().getName()))
                        try {
                            dos.writeUTF(containerPri.get(i));
                            dos.flush();
                            containerPri.remove(i);
                            i--;                                    //
                        } catch (IOException ioe) {
                            ioe.printStackTrace();
                            TogetherClose.close(dos, bos, client);
                            System.out.println("服务器，发送，私聊，报错");
                            break;
                        }
                }
            }
            if(containerGro.isEmpty())
                continue;
            synchronized(containerGro){            //这个东西的地址是会不断变化的，它并不是真正意义上的链表，
                                                   // 而是一个可以扩大的数组，随着增大，会得到新的地址，所以这里锁它肯定是有毛病的，但暂时不管
                if(containerGro.isEmpty())
                    continue;
                String mesg=containerGro.get(0);
                for(int i=0;i<clients.size();i++){
                    try {
                        if(!clients.get(i).isClosed()) {
                            BufferedOutputStream bosTemp = new BufferedOutputStream(clients.get(i).getOutputStream());
                            DataOutputStream dosTemp = new DataOutputStream(bosTemp);
                            dosTemp.writeUTF(">>>ALL " + mesg);
                            dosTemp.flush();
//                        System.out.println("输出群聊 "+mesg);
                        }
                    }catch (IOException ioe){
                        System.out.println("发送，群聊，服务器，synchronized报错");
                        ioe.printStackTrace();
                        break;
                    }
                }
                containerGro.remove(0);
            }
        }
    }

}
