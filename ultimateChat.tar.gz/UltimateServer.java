import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class UltimateServer {
    private static int num;
    private static String[] name={"A","B","C","D","E","F","G","H","I","J","K"};
    public static void main(String[] a){
        List<String> containerPri=new ArrayList<>(200);
        List<String> containerGro=new ArrayList<>(100);
        ServerSocket serverSocket;
        Socket client;
         List<Socket> clients=new ArrayList<>(25);
        try {
            serverSocket = new ServerSocket(8888);
            while (true){
                client=serverSocket.accept();
                clients.add(client);
                try {
                    new Thread(new Send(client,containerPri,containerGro,clients),name[num]).start();
                    new Thread(new Receive(client,containerPri,containerGro,name)).start();
                }catch(IOException ioe){
                    ioe.printStackTrace();
                }
                for(int i=0;i<clients.size();i++){
                    if(!clients.get(i).isConnected()){
                        TogetherClose.close(clients.get(i));
                        System.out.println("服务器，移除一个客户端");
                        clients.remove(i);
                        i--;
                    }
                }
                System.out.println("今天第 "+clients.size()+"位沙雕 "+name[num]+" 加入房间！");
                containerGro.add("系统通知：今天的第 "+clients.size()+" 位沙雕 >>>"+name[num]+"<<< 加入房间！");
                if(num>11){
                    TogetherClose.close(serverSocket);
                    break;
                }
                num++;
//                System.out.println("server group容器： "+containerGro);
//                System.out.println("server private容器： "+containerPri);

            }
        }catch (IOException ioe){
            ioe.printStackTrace();
            System.out.println("接收，服务器，ioe，报错");
        }
    }
}
